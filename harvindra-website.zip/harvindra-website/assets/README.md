# Assets Folder

Place these files here:

1. **CV_Harvindra_Singh.pdf** — your CV file (linked from the "Download CV" button)
2. **profile.jpg** (optional) — a square profile photo (see README.md for instructions on how to enable it)

The website's "Download CV" button currently points to:

```
assets/CV_Harvindra_Singh.pdf
```

If you upload your CV with a different filename, update the link in `index.html`:

```html
<a href="assets/YOUR_FILENAME.pdf" class="btn btn-primary" download>
```
